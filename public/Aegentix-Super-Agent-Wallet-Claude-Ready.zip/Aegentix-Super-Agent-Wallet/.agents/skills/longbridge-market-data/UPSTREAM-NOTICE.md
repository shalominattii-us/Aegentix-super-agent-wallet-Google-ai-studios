# Upstream helpers for longbridge-market-data

The files listed below were recovered from [longbridge/skills](https://github.com/longbridge/skills) at commit `66f45635ac0c7000b714ed0f34ab400b6818be74`. The repository ID is `1224163986`.

They retain the upstream **MIT** license reproduced in [UPSTREAM-LICENSE.txt](UPSTREAM-LICENSE.txt). This notice applies to the listed support files; it does not replace the license metadata of other catalog files. Preserve the upstream license and this attribution when redistributing them.

License wording is unchanged; text-only trailing whitespace and EOF blank lines are normalized. Original license: https://github.com/longbridge/skills/blob/66f45635ac0c7000b714ed0f34ab400b6818be74/LICENSE

| Local file | Original upstream path | Original Git blob SHA | Import changes |
| --- | --- | --- | --- |
| `references/quote.md` | `skills/longbridge-market-data/references/quote.md` | `bc41861cbb760400035000fa34ff1e6ed26f2583` | text-only trailing whitespace and EOF blank lines normalized |
| `references/kline.md` | `skills/longbridge-market-data/references/kline.md` | `d0102a027d45d739a810d889074472801a2cc5d3` | text-only trailing whitespace and EOF blank lines normalized |
| `references/depth.md` | `skills/longbridge-market-data/references/depth.md` | `f60c214cba7ba84d141f746c15b7655949af32cc` | text-only trailing whitespace and EOF blank lines normalized |
| `references/trades.md` | `skills/longbridge-market-data/references/trades.md` | `116d7afabfa61aba4794844e9460fa8b3b0eddc8` | text-only trailing whitespace and EOF blank lines normalized |
| `references/intraday.md` | `skills/longbridge-market-data/references/intraday.md` | `36e93696ec54d6651c1bc4c1962e4636ae5811c6` | text-only trailing whitespace and EOF blank lines normalized |
| `references/capital.md` | `skills/longbridge-market-data/references/capital.md` | `e07e0c2789edd44014c8ee9c79840b470d5ba5e4` | text-only trailing whitespace and EOF blank lines normalized |
| `references/market-temp.md` | `skills/longbridge-market-data/references/market-temp.md` | `3162a7ceb11915f82bafb23d4fd61b32741680b8` | text-only trailing whitespace and EOF blank lines normalized |
| `references/trading.md` | `skills/longbridge-market-data/references/trading.md` | `cbbfa38418ccd9925c3a90c3db4fdc5f0a2b0572` | text-only trailing whitespace and EOF blank lines normalized |
| `references/security-list.md` | `skills/longbridge-market-data/references/security-list.md` | `509a1082f83709cdd6642f6dbc536621682f1fb3` | text-only trailing whitespace and EOF blank lines normalized |
| `references/participants.md` | `skills/longbridge-market-data/references/participants.md` | `2a63815cca7da725d6292ddbe1e630fdcad75191` | text-only trailing whitespace and EOF blank lines normalized |
| `references/subscriptions.md` | `skills/longbridge-market-data/references/subscriptions.md` | `d22fdd32f9b0932e2ece2754749f9d9b4b3e844a` | text-only trailing whitespace and EOF blank lines normalized |
| `references/ah-premium.md` | `skills/longbridge-market-data/references/ah-premium.md` | `55ec3147032c853f84ba3471a4724a6b5edcec78` | text-only trailing whitespace and EOF blank lines normalized |
| `references/trade-stats.md` | `skills/longbridge-market-data/references/trade-stats.md` | `3d22870996f5ecd46a8b67962dd4b2deb781b808` | text-only trailing whitespace and EOF blank lines normalized |
| `references/market-status.md` | `skills/longbridge-market-data/references/market-status.md` | `9af1cad7dfcf8e07238ceef050b7cd7550f62728` | text-only trailing whitespace and EOF blank lines normalized |
| `references/exchange-rate.md` | `skills/longbridge-market-data/references/exchange-rate.md` | `7b2c50265bc6ca1e29bcd01f1175c0eda2faf4aa` | text-only trailing whitespace and EOF blank lines normalized |
| `references/ipo.md` | `skills/longbridge-market-data/references/ipo.md` | `75a85f04804eb38e45d54164229c63663ca01573` | text-only trailing whitespace and EOF blank lines normalized |
| `references/adr-premium.md` | `skills/longbridge-market-data/references/adr-premium.md` | `a1ee7ba5802ec39b7474c2afc0976b3c21f71ed2` | text-only trailing whitespace and EOF blank lines normalized |
| `references/fx-carry.md` | `skills/longbridge-market-data/references/fx-carry.md` | `76232f6fa40aea5e9883066fcf8791de03118723` | text-only trailing whitespace and EOF blank lines normalized |
